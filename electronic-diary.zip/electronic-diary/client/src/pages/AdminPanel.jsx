import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import toast from 'react-hot-toast'
import Loader from '../components/Loader'

const ROLE_LABELS = { student: 'Ученик', teacher: 'Учитель', admin: 'Администратор' }

const AdminPanel = () => {
  const { user: currentUser } = useAuth()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingUser, setEditingUser] = useState(null)
  const [saving, setSaving] = useState(false)
  const [filterRole, setFilterRole] = useState('')
  const [search, setSearch] = useState('')

  useEffect(() => { fetchUsers() }, [])

  const fetchUsers = async () => {
    try {
      const { data } = await api.get('/users')
      setUsers(data)
    } catch {
      toast.error('Ошибка загрузки пользователей')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!editingUser) return
    setSaving(true)
    try {
      const { data } = await api.put(`/users/${editingUser._id}`, editingUser)
      setUsers((prev) => prev.map((u) => (u._id === data._id ? data : u)))
      setEditingUser(null)
      toast.success('Пользователь обновлён')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка обновления')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Удалить пользователя "${name}"? Это действие необратимо.`)) return
    try {
      await api.delete(`/users/${id}`)
      setUsers((prev) => prev.filter((u) => u._id !== id))
      toast.success(`${name} удалён`)
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка удаления')
    }
  }

  const filtered = users.filter((u) => {
    const matchRole = filterRole ? u.role === filterRole : true
    const matchSearch = search
      ? u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase())
      : true
    return matchRole && matchSearch
  })

  const stats = {
    total: users.length,
    students: users.filter((u) => u.role === 'student').length,
    teachers: users.filter((u) => u.role === 'teacher').length,
    admins: users.filter((u) => u.role === 'admin').length,
  }

  if (loading) return <Loader text="Загрузка панели администратора..." />

  return (
    <main className="page">
      <section className="page-header">
        <div>
          <h1 className="page-title">Панель администратора</h1>
          <p className="page-subtitle">Управление пользователями системы</p>
        </div>
      </section>

      {/* Статистика */}
      <section className="stats-grid" aria-label="Статистика пользователей">
        <article className="stat-card stat-card--blue">
          <span className="stat-value">{stats.total}</span>
          <span className="stat-label">Всего пользователей</span>
        </article>
        <article className="stat-card stat-card--green">
          <span className="stat-value">{stats.students}</span>
          <span className="stat-label">Учеников</span>
        </article>
        <article className="stat-card stat-card--yellow">
          <span className="stat-value">{stats.teachers}</span>
          <span className="stat-label">Учителей</span>
        </article>
        <article className="stat-card stat-card--red">
          <span className="stat-value">{stats.admins}</span>
          <span className="stat-label">Администраторов</span>
        </article>
      </section>

      {/* Фильтры */}
      <section className="filter-bar">
        <input
          type="text"
          className="form-input filter-search"
          placeholder="🔍 Поиск по имени или email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="form-input filter-select" value={filterRole} onChange={(e) => setFilterRole(e.target.value)}>
          <option value="">Все роли</option>
          <option value="student">Ученики</option>
          <option value="teacher">Учителя</option>
          <option value="admin">Администраторы</option>
        </select>
      </section>

      {/* Форма редактирования */}
      {editingUser && (
        <section className="form-card" aria-labelledby="edit-user-title">
          <h2 id="edit-user-title" className="card-title">Редактирование: {editingUser.name}</h2>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Имя</label>
              <input className="form-input" value={editingUser.name}
                onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" value={editingUser.email}
                onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Роль</label>
              <select className="form-input" value={editingUser.role}
                onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value })}>
                <option value="student">Ученик</option>
                <option value="teacher">Учитель</option>
                <option value="admin">Администратор</option>
              </select>
            </div>
            {editingUser.role === 'student' && (
              <div className="form-group">
                <label className="form-label">Класс</label>
                <input className="form-input" value={editingUser.class || ''}
                  onChange={(e) => setEditingUser({ ...editingUser, class: e.target.value })} />
              </div>
            )}
            {editingUser.role === 'teacher' && (
              <div className="form-group">
                <label className="form-label">Предмет</label>
                <input className="form-input" value={editingUser.subject || ''}
                  onChange={(e) => setEditingUser({ ...editingUser, subject: e.target.value })} />
              </div>
            )}
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? <><span className="btn-spinner" /> Сохранение...</> : 'Сохранить'}
            </button>
            <button className="btn btn-ghost" onClick={() => setEditingUser(null)}>Отмена</button>
          </div>
        </section>
      )}

      {/* Таблица пользователей */}
      <section className="table-card" aria-label="Список пользователей">
        <p className="table-count">Показано: {filtered.length} из {users.length}</p>
        {filtered.length === 0 ? (
          <p className="empty-state">Пользователи не найдены</p>
        ) : (
          <div className="table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Имя</th>
                  <th>Email</th>
                  <th>Роль</th>
                  <th>Класс / Предмет</th>
                  <th>Дата регистрации</th>
                  <th>Действия</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u) => (
                  <tr key={u._id} className={u._id === currentUser._id ? 'row-current' : ''}>
                    <td>
                      <div className="user-cell">
                        {u.avatar ? (
                          <img src={u.avatar} alt="" className="user-avatar-sm" />
                        ) : (
                          <div className="user-avatar-sm user-avatar-placeholder">{u.name[0]}</div>
                        )}
                        {u.name}
                        {u._id === currentUser._id && <span className="badge-you">Вы</span>}
                      </div>
                    </td>
                    <td>{u.email}</td>
                    <td>
                      <span className={`role-badge role-badge--${u.role}`}>{ROLE_LABELS[u.role]}</span>
                    </td>
                    <td>{u.class || u.subject || '—'}</td>
                    <td>{new Date(u.createdAt).toLocaleDateString('ru-RU')}</td>
                    <td>
                      <div className="action-btns">
                        <button className="btn-icon btn-icon--edit" onClick={() => setEditingUser({ ...u })}>✏️</button>
                        {u._id !== currentUser._id && (
                          <button className="btn-icon btn-icon--delete" onClick={() => handleDelete(u._id, u.name)}>🗑️</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  )
}

export default AdminPanel
