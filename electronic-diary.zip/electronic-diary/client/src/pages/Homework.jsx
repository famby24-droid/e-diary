import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import toast from 'react-hot-toast'
import Loader from '../components/Loader'

const Homework = () => {
  const { user } = useAuth()
  const [homework, setHomework] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingHW, setEditingHW] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [files, setFiles] = useState([])

  const canManage = user?.role === 'teacher' || user?.role === 'admin'
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm()

  useEffect(() => { fetchHomework() }, [])

  const fetchHomework = async () => {
    try {
      const { data } = await api.get('/homework')
      setHomework(data)
    } catch {
      toast.error('Не удалось загрузить задания')
    } finally {
      setLoading(false)
    }
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (editingHW) {
        const res = await api.put(`/homework/${editingHW._id}`, data)
        setHomework((prev) => prev.map((h) => (h._id === editingHW._id ? res.data : h)))
        toast.success('Задание обновлено')
        resetForm()
      } else {
        const formData = new FormData()
        Object.entries(data).forEach(([k, v]) => formData.append(k, v))
        files.forEach((f) => formData.append('attachments', f))

        const res = await api.post('/homework', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        })
        setHomework((prev) => [res.data, ...prev])
        toast.success('Задание добавлено')
        resetForm()
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка сохранения')
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = (hw) => {
    setEditingHW(hw)
    setShowForm(true)
    setValue('class', hw.class)
    setValue('subject', hw.subject)
    setValue('description', hw.description)
    setValue('dueDate', new Date(hw.dueDate).toISOString().split('T')[0])
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить задание?')) return
    try {
      await api.delete(`/homework/${id}`)
      setHomework((prev) => prev.filter((h) => h._id !== id))
      toast.success('Задание удалено')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка')
    }
  }

  const resetForm = () => { reset(); setShowForm(false); setEditingHW(null); setFiles([]) }

  const isOverdue = (date) => new Date(date) < new Date()
  const daysLeft = (date) => {
    const diff = Math.ceil((new Date(date) - new Date()) / (1000 * 60 * 60 * 24))
    if (diff < 0) return 'Просрочено'
    if (diff === 0) return 'Сегодня!'
    return `${diff} дн.`
  }

  if (loading) return <Loader text="Загрузка заданий..." />

  return (
    <main className="page">
      <section className="page-header">
        <div>
          <h1 className="page-title">Домашние задания</h1>
          <p className="page-subtitle">Всего заданий: {homework.length}</p>
        </div>
        {canManage && (
          <button className="btn btn-primary" onClick={() => { resetForm(); setShowForm(true) }}>
            + Добавить задание
          </button>
        )}
      </section>

      {/* Форма */}
      {showForm && canManage && (
        <section className="form-card" aria-labelledby="hw-form-title">
          <h2 id="hw-form-title" className="card-title">
            {editingHW ? 'Редактировать задание' : 'Новое задание'}
          </h2>
          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Класс</label>
                <input className={`form-input ${errors.class ? 'form-input--error' : ''}`}
                  placeholder="10А" {...register('class', { required: 'Укажите класс' })} />
                {errors.class && <span className="form-error">{errors.class.message}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Предмет</label>
                <input className={`form-input ${errors.subject ? 'form-input--error' : ''}`}
                  placeholder="Математика" defaultValue={user?.subject}
                  {...register('subject', { required: 'Укажите предмет' })} />
                {errors.subject && <span className="form-error">{errors.subject.message}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Срок сдачи</label>
                <input type="date" className={`form-input ${errors.dueDate ? 'form-input--error' : ''}`}
                  {...register('dueDate', { required: 'Укажите срок' })} />
                {errors.dueDate && <span className="form-error">{errors.dueDate.message}</span>}
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Описание задания</label>
              <textarea className={`form-input form-textarea ${errors.description ? 'form-input--error' : ''}`}
                placeholder="Подробное описание задания..."
                {...register('description', { required: 'Опишите задание', minLength: { value: 5, message: 'Минимум 5 символов' } })} />
              {errors.description && <span className="form-error">{errors.description.message}</span>}
            </div>
            {!editingHW && (
              <div className="form-group">
                <label className="form-label">Прикрепить файлы (до 5)</label>
                <input type="file" multiple accept="*/*" className="form-input"
                  onChange={(e) => setFiles(Array.from(e.target.files))} />
                {files.length > 0 && (
                  <ul className="file-list">
                    {files.map((f, i) => <li key={i} className="file-item">📎 {f.name}</li>)}
                  </ul>
                )}
              </div>
            )}
            <div className="form-actions">
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? <><span className="btn-spinner" /> Сохранение...</> : 'Сохранить'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={resetForm}>Отмена</button>
            </div>
          </form>
        </section>
      )}

      {/* Список заданий */}
      {homework.length === 0 ? (
        <p className="empty-state">Заданий пока нет</p>
      ) : (
        <ul className="hw-cards">
          {homework.map((hw) => (
            <li key={hw._id} className={`hw-card ${isOverdue(hw.dueDate) ? 'hw-card--overdue' : ''}`}>
              <div className="hw-card-header">
                <div>
                  <span className="hw-card-subject">{hw.subject}</span>
                  <span className="hw-card-class">Класс {hw.class}</span>
                </div>
                <div className="hw-card-meta">
                  <span className={`hw-deadline ${isOverdue(hw.dueDate) ? 'hw-deadline--overdue' : ''}`}>
                    ⏰ {daysLeft(hw.dueDate)}
                  </span>
                  <span className="hw-date">
                    до {new Date(hw.dueDate).toLocaleDateString('ru-RU')}
                  </span>
                </div>
              </div>
              <p className="hw-description">{hw.description}</p>
              {hw.teacher && (
                <p className="hw-teacher">👨‍🏫 {hw.teacher.name}</p>
              )}
              {hw.attachments?.length > 0 && (
                <ul className="hw-attachments">
                  {hw.attachments.map((a, i) => (
                    <li key={i}>
                      <a href={a.path} target="_blank" rel="noreferrer" className="attachment-link">
                        📎 {a.originalName}
                      </a>
                    </li>
                  ))}
                </ul>
              )}
              {canManage && (
                <div className="hw-actions">
                  <button className="btn-icon btn-icon--edit" onClick={() => handleEdit(hw)}>✏️ Изменить</button>
                  <button className="btn-icon btn-icon--delete" onClick={() => handleDelete(hw._id)}>🗑️ Удалить</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </main>
  )
}

export default Homework
