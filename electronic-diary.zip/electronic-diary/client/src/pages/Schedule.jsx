import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import toast from 'react-hot-toast'
import Loader from '../components/Loader'

const DAYS = ['', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота']
const LESSON_TIMES = [
  '', '08:00–08:45', '08:55–09:40', '09:50–10:35',
  '10:55–11:40', '11:50–12:35', '12:45–13:30', '13:40–14:25', '14:35–15:20',
]

const Schedule = () => {
  const { user } = useAuth()
  const [schedule, setSchedule] = useState([])
  const [teachers, setTeachers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingLesson, setEditingLesson] = useState(null)
  const [filterClass, setFilterClass] = useState(user?.class || '')
  const [submitting, setSubmitting] = useState(false)

  const isAdmin = user?.role === 'admin'
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm()

  useEffect(() => {
    fetchSchedule()
    if (isAdmin) fetchTeachers()
  }, [filterClass])

  const fetchSchedule = async () => {
    setLoading(true)
    try {
      const params = filterClass ? `?class=${filterClass}` : ''
      const { data } = await api.get(`/schedule${params}`)
      setSchedule(data)
    } catch {
      toast.error('Не удалось загрузить расписание')
    } finally {
      setLoading(false)
    }
  }

  const fetchTeachers = async () => {
    try {
      const { data } = await api.get('/users?role=teacher')
      setTeachers(data)
    } catch {}
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      const payload = { ...data, dayOfWeek: Number(data.dayOfWeek), lessonNumber: Number(data.lessonNumber) }
      if (editingLesson) {
        const res = await api.put(`/schedule/${editingLesson._id}`, payload)
        setSchedule((prev) => prev.map((l) => (l._id === editingLesson._id ? res.data : l)))
        toast.success('Урок обновлён')
      } else {
        const res = await api.post('/schedule', payload)
        setSchedule((prev) => [...prev, res.data])
        toast.success('Урок добавлен')
      }
      resetForm()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка сохранения')
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = (lesson) => {
    setEditingLesson(lesson)
    setShowForm(true)
    Object.entries(lesson).forEach(([k, v]) => {
      if (k === 'teacher') setValue(k, v?._id)
      else setValue(k, v)
    })
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить урок?')) return
    try {
      await api.delete(`/schedule/${id}`)
      setSchedule((prev) => prev.filter((l) => l._id !== id))
      toast.success('Урок удалён')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка')
    }
  }

  const resetForm = () => { reset(); setShowForm(false); setEditingLesson(null) }

  // Группируем по дням
  const byDay = DAYS.reduce((acc, _, i) => {
    if (i === 0) return acc
    acc[i] = schedule.filter((l) => l.dayOfWeek === i).sort((a, b) => a.lessonNumber - b.lessonNumber)
    return acc
  }, {})

  if (loading) return <Loader text="Загрузка расписания..." />

  return (
    <main className="page">
      <section className="page-header">
        <div>
          <h1 className="page-title">Расписание</h1>
          {filterClass && <p className="page-subtitle">Класс: {filterClass}</p>}
        </div>
        <div className="header-actions">
          {(isAdmin || user?.role === 'teacher') && (
            <div className="form-group mb-0">
              <input
                type="text"
                className="form-input"
                placeholder="Фильтр по классу (10А)"
                value={filterClass}
                onChange={(e) => setFilterClass(e.target.value)}
              />
            </div>
          )}
          {isAdmin && (
            <button className="btn btn-primary" onClick={() => { resetForm(); setShowForm(true) }}>
              + Добавить урок
            </button>
          )}
        </div>
      </section>

      {/* Форма */}
      {showForm && isAdmin && (
        <section className="form-card" aria-labelledby="schedule-form-title">
          <h2 id="schedule-form-title" className="card-title">
            {editingLesson ? 'Редактировать урок' : 'Новый урок'}
          </h2>
          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Класс</label>
                <input className={`form-input ${errors.class ? 'form-input--error' : ''}`}
                  placeholder="10А" {...register('class', { required: 'Укажите класс' })} />
                {errors.class && <span className="form-error">{errors.class.message}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">День недели</label>
                <select className={`form-input ${errors.dayOfWeek ? 'form-input--error' : ''}`}
                  {...register('dayOfWeek', { required: 'Выберите день' })}>
                  <option value="">Выберите день</option>
                  {DAYS.slice(1).map((d, i) => <option key={i+1} value={i+1}>{d}</option>)}
                </select>
                {errors.dayOfWeek && <span className="form-error">{errors.dayOfWeek.message}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Номер урока</label>
                <select className={`form-input ${errors.lessonNumber ? 'form-input--error' : ''}`}
                  {...register('lessonNumber', { required: 'Выберите номер' })}>
                  <option value="">Выберите</option>
                  {LESSON_TIMES.slice(1).map((t, i) => (
                    <option key={i+1} value={i+1}>{i+1} ({t})</option>
                  ))}
                </select>
                {errors.lessonNumber && <span className="form-error">{errors.lessonNumber.message}</span>}
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Предмет</label>
                <input className={`form-input ${errors.subject ? 'form-input--error' : ''}`}
                  placeholder="Математика" {...register('subject', { required: 'Укажите предмет' })} />
                {errors.subject && <span className="form-error">{errors.subject.message}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Учитель</label>
                <select className="form-input" {...register('teacher')}>
                  <option value="">Не назначен</option>
                  {teachers.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Кабинет</label>
                <input className="form-input" placeholder="205" {...register('room')} />
              </div>
            </div>
            <div className="form-actions">
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? <><span className="btn-spinner" /> Сохранение...</> : 'Сохранить'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={resetForm}>Отмена</button>
            </div>
          </form>
        </section>
      )}

      {/* Расписание по дням */}
      {schedule.length === 0 ? (
        <p className="empty-state">Расписание не найдено{filterClass ? ` для класса ${filterClass}` : ''}</p>
      ) : (
        <div className="schedule-grid">
          {Object.entries(byDay).map(([day, lessons]) => lessons.length > 0 && (
            <section key={day} className="schedule-day" aria-labelledby={`day-${day}`}>
              <h2 id={`day-${day}`} className="schedule-day-title">{DAYS[day]}</h2>
              <ul className="lesson-list">
                {lessons.map((l) => (
                  <li key={l._id} className="lesson-item">
                    <div className="lesson-number">{l.lessonNumber}</div>
                    <div className="lesson-info">
                      <span className="lesson-time">{LESSON_TIMES[l.lessonNumber]}</span>
                      <span className="lesson-subject">{l.subject}</span>
                      {l.teacher && <span className="lesson-teacher">{l.teacher.name}</span>}
                      {l.room && <span className="lesson-room">Каб. {l.room}</span>}
                    </div>
                    {isAdmin && (
                      <div className="action-btns">
                        <button className="btn-icon btn-icon--edit" onClick={() => handleEdit(l)}>✏️</button>
                        <button className="btn-icon btn-icon--delete" onClick={() => handleDelete(l._id)}>🗑️</button>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </main>
  )
}

export default Schedule
