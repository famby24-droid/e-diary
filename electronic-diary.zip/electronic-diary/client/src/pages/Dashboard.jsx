import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import Loader from '../components/Loader'

const Dashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState(null)
  const [recentGrades, setRecentGrades] = useState([])
  const [upcomingHW, setUpcomingHW] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const [gradesRes, hwRes] = await Promise.all([
          api.get('/grades'),
          api.get('/homework'),
        ])

        const grades = gradesRes.data
        const homework = hwRes.data

        // Считаем статистику
        if (grades.length > 0) {
          const avg = grades.reduce((s, g) => s + g.value, 0) / grades.length
          const counts = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
          grades.forEach((g) => { counts[g.value] = (counts[g.value] || 0) + 1 })
          setStats({ avg: avg.toFixed(1), total: grades.length, counts })
        }

        setRecentGrades(grades.slice(0, 5))
        setUpcomingHW(homework.filter((h) => new Date(h.dueDate) >= new Date()).slice(0, 3))
      } catch (err) {
        console.error('Ошибка загрузки дашборда', err)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboard()
  }, [])

  const gradeColor = (v) => {
    if (v >= 5) return 'grade-5'
    if (v >= 4) return 'grade-4'
    if (v >= 3) return 'grade-3'
    return 'grade-2'
  }

  const formatDate = (d) =>
    new Date(d).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })

  if (loading) return <Loader text="Загрузка данных..." />

  return (
    <main className="page">
      <section className="page-header">
        <div>
          <h1 className="page-title">Добро пожаловать, {user?.name?.split(' ')[0]}! 👋</h1>
          <p className="page-subtitle">
            {user?.role === 'student' && `Класс: ${user.class || 'не указан'}`}
            {user?.role === 'teacher' && `Предмет: ${user.subject || 'не указан'}`}
            {user?.role === 'admin' && 'Панель администратора'}
          </p>
        </div>
      </section>

      {/* Карточки статистики */}
      {stats && user?.role === 'student' && (
        <section className="stats-grid" aria-label="Статистика оценок">
          <article className="stat-card stat-card--blue">
            <span className="stat-value">{stats.avg}</span>
            <span className="stat-label">Средний балл</span>
          </article>
          <article className="stat-card stat-card--green">
            <span className="stat-value">{stats.counts[5] || 0}</span>
            <span className="stat-label">Пятёрок</span>
          </article>
          <article className="stat-card stat-card--yellow">
            <span className="stat-value">{stats.counts[4] || 0}</span>
            <span className="stat-label">Четвёрок</span>
          </article>
          <article className="stat-card stat-card--red">
            <span className="stat-value">{stats.total}</span>
            <span className="stat-label">Всего оценок</span>
          </article>
        </section>
      )}

      <div className="dashboard-grid">
        {/* Последние оценки */}
        <section className="dashboard-card" aria-labelledby="recent-grades-title">
          <div className="card-header">
            <h2 id="recent-grades-title" className="card-title">Последние оценки</h2>
            <Link to="/grades" className="card-link">Все оценки →</Link>
          </div>
          {recentGrades.length === 0 ? (
            <p className="empty-state">Оценок пока нет</p>
          ) : (
            <ul className="grade-list">
              {recentGrades.map((g) => (
                <li key={g._id} className="grade-item">
                  <div>
                    <span className="grade-subject">{g.subject}</span>
                    {user?.role !== 'student' && (
                      <span className="grade-student">{g.student?.name}</span>
                    )}
                    <span className="grade-date">{formatDate(g.date)}</span>
                  </div>
                  <span className={`grade-badge ${gradeColor(g.value)}`}>{g.value}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Ближайшие задания */}
        <section className="dashboard-card" aria-labelledby="upcoming-hw-title">
          <div className="card-header">
            <h2 id="upcoming-hw-title" className="card-title">Ближайшие задания</h2>
            <Link to="/homework" className="card-link">Все задания →</Link>
          </div>
          {upcomingHW.length === 0 ? (
            <p className="empty-state">Заданий нет</p>
          ) : (
            <ul className="hw-list">
              {upcomingHW.map((hw) => (
                <li key={hw._id} className="hw-item">
                  <div className="hw-info">
                    <span className="hw-subject">{hw.subject}</span>
                    <p className="hw-desc">{hw.description.substring(0, 80)}...</p>
                  </div>
                  <span className="hw-due">до {formatDate(hw.dueDate)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Быстрые ссылки */}
      <section className="quick-links" aria-labelledby="quick-links-title">
        <h2 id="quick-links-title" className="section-title">Быстрый переход</h2>
        <nav className="quick-links-grid">
          <Link to="/grades" className="quick-link-card">
            <span className="quick-icon">📊</span>
            <span>Оценки</span>
          </Link>
          <Link to="/schedule" className="quick-link-card">
            <span className="quick-icon">📅</span>
            <span>Расписание</span>
          </Link>
          <Link to="/homework" className="quick-link-card">
            <span className="quick-icon">📝</span>
            <span>Домашние задания</span>
          </Link>
          <Link to="/profile" className="quick-link-card">
            <span className="quick-icon">👤</span>
            <span>Профиль</span>
          </Link>
        </nav>
      </section>
    </main>
  )
}

export default Dashboard
