import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'

const Register = () => {
  const { register: registerUser } = useAuth()
  const navigate = useNavigate()
  const [isLoading, setIsLoading] = useState(false)

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({ defaultValues: { role: 'student' } })

  const selectedRole = watch('role')

  const onSubmit = async (data) => {
    setIsLoading(true)
    try {
      await registerUser({
        name: data.name,
        email: data.email,
        password: data.password,
        role: data.role,
        class: data.class,
        subject: data.subject,
      })
      toast.success('Аккаунт создан!')
      navigate('/dashboard')
    } catch (err) {
      const msg = err.response?.data?.message || 'Ошибка регистрации'
      toast.error(msg)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="auth-page">
      <section className="auth-card auth-card--wide" aria-labelledby="register-title">
        <div className="auth-header">
          <span className="auth-icon">📓</span>
          <h1 id="register-title" className="auth-title">Регистрация</h1>
          <p className="auth-subtitle">Создайте аккаунт в системе</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="form-group">
            <label htmlFor="name" className="form-label">Полное имя</label>
            <input
              id="name"
              type="text"
              className={`form-input ${errors.name ? 'form-input--error' : ''}`}
              placeholder="Иванов Иван Иванович"
              {...register('name', {
                required: 'Введите имя',
                minLength: { value: 2, message: 'Минимум 2 символа' },
              })}
            />
            {errors.name && <span className="form-error">{errors.name.message}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              id="email"
              type="email"
              className={`form-input ${errors.email ? 'form-input--error' : ''}`}
              placeholder="example@school.kz"
              {...register('email', {
                required: 'Введите email',
                pattern: { value: /^\S+@\S+\.\S+$/, message: 'Некорректный email' },
              })}
            />
            {errors.email && <span className="form-error">{errors.email.message}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="password" className="form-label">Пароль</label>
            <input
              id="password"
              type="password"
              className={`form-input ${errors.password ? 'form-input--error' : ''}`}
              placeholder="Минимум 6 символов"
              {...register('password', {
                required: 'Введите пароль',
                minLength: { value: 6, message: 'Минимум 6 символов' },
              })}
            />
            {errors.password && <span className="form-error">{errors.password.message}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Роль</label>
            <div className="role-selector">
              {[
                { value: 'student', label: '🎓 Ученик' },
                { value: 'teacher', label: '👨‍🏫 Учитель' },
                { value: 'admin', label: '⚙️ Администратор' },
              ].map((r) => (
                <label key={r.value} className={`role-option ${selectedRole === r.value ? 'role-option--active' : ''}`}>
                  <input type="radio" value={r.value} {...register('role')} className="sr-only" />
                  {r.label}
                </label>
              ))}
            </div>
          </div>

          {selectedRole === 'student' && (
            <div className="form-group">
              <label htmlFor="class" className="form-label">Класс</label>
              <input
                id="class"
                type="text"
                className={`form-input ${errors.class ? 'form-input--error' : ''}`}
                placeholder="Например: 10А"
                {...register('class', { required: 'Укажите класс' })}
              />
              {errors.class && <span className="form-error">{errors.class.message}</span>}
            </div>
          )}

          {selectedRole === 'teacher' && (
            <div className="form-group">
              <label htmlFor="subject" className="form-label">Предмет</label>
              <input
                id="subject"
                type="text"
                className={`form-input ${errors.subject ? 'form-input--error' : ''}`}
                placeholder="Например: Математика"
                {...register('subject', { required: 'Укажите предмет' })}
              />
              {errors.subject && <span className="form-error">{errors.subject.message}</span>}
            </div>
          )}

          <button type="submit" className="btn btn-primary btn-full" disabled={isLoading}>
            {isLoading ? <><span className="btn-spinner" /> Создание...</> : 'Создать аккаунт'}
          </button>
        </form>

        <p className="auth-switch">
          Уже есть аккаунт?{' '}
          <Link to="/login" className="auth-link">Войти</Link>
        </p>
      </section>
    </main>
  )
}

export default Register
