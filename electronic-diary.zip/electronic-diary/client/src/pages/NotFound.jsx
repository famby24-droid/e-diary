import { Link } from 'react-router-dom'

const NotFound = () => (
  <main className="not-found-page">
    <div className="not-found-content">
      <span className="not-found-code">404</span>
      <h1 className="not-found-title">Страница не найдена</h1>
      <p className="not-found-desc">Такой страницы не существует или она была удалена.</p>
      <Link to="/dashboard" className="btn btn-primary">
        ← Вернуться на главную
      </Link>
    </div>
  </main>
)

export default NotFound
