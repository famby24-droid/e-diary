import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import toast from 'react-hot-toast'
import Loader from '../components/Loader'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'

const GRADE_TYPES = {
  classwork: 'Классная работа',
  homework: 'Домашняя работа',
  test: 'Контрольная',
  exam: 'Экзамен',
}

const Grades = () => {
  const { user } = useAuth()
  const [grades, setGrades] = useState([])
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingGrade, setEditingGrade] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const canManage = user?.role === 'teacher' || user?.role === 'admin'

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm()

  useEffect(() => {
    fetchGrades()
    if (canManage) fetchStudents()
  }, [])

  const fetchGrades = async () => {
    try {
      const { data } = await api.get('/grades')
      setGrades(data)
    } catch {
      toast.error('Не удалось загрузить оценки')
    } finally {
      setLoading(false)
    }
  }

  const fetchStudents = async () => {
    try {
      const { data } = await api.get('/users?role=student')
      setStudents(data)
    } catch {
      console.error('Ошибка загрузки учеников')
    }
  }

  const onSubmit = async (data) => {
    setSubmitting(true)
    try {
      if (editingGrade) {
        const res = await api.put(`/grades/${editingGrade._id}`, data)
        setGrades((prev) => prev.map((g) => (g._id === editingGrade._id ? res.data : g)))
        toast.success('Оценка обновлена')
      } else {
        const res = await api.post('/grades', data)
        setGrades((prev) => [res.data, ...prev])
        toast.success('Оценка добавлена')
      }
      resetForm()
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка сохранения')
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = (grade) => {
    setEditingGrade(grade)
    setShowForm(true)
    setValue('studentId', grade.student?._id)
    setValue('subject', grade.subject)
    setValue('value', grade.value)
    setValue('comment', grade.comment || '')
    setValue('type', grade.type)
    setValue('date', new Date(grade.date).toISOString().split('T')[0])
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Удалить оценку?')) return
    try {
      await api.delete(`/grades/${id}`)
      setGrades((prev) => prev.filter((g) => g._id !== id))
      toast.success('Оценка удалена')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка удаления')
    }
  }

  const resetForm = () => {
    reset()
    setShowForm(false)
    setEditingGrade(null)
  }

  // Данные для графика
  const chartData = [5, 4, 3, 2, 1].map((v) => ({
    name: `${v}`,
    count: grades.filter((g) => g.value === v).length,
  }))

  const COLORS = { '5': '#22c55e', '4': '#3b82f6', '3': '#f59e0b', '2': '#ef4444', '1': '#7f1d1d' }

  const gradeColor = (v) => ['', 'grade-1', 'grade-2', 'grade-3', 'grade-4', 'grade-5'][v]

  if (loading) return <Loader text="Загрузка оценок..." />

  return (
    <main className="page">
      <section className="page-header">
        <div>
          <h1 className="page-title">Оценки</h1>
          <p className="page-subtitle">Всего записей: {grades.length}</p>
        </div>
        {canManage && (
          <button className="btn btn-primary" onClick={() => { resetForm(); setShowForm(true) }}>
            + Добавить оценку
          </button>
        )}
      </section>

      {/* График распределения */}
      {grades.length > 0 && (
        <section className="chart-card" aria-label="График оценок">
          <h2 className="card-title">Распределение оценок</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis allowDecimals={false} />
              <Tooltip formatter={(v) => [`${v} оценок`, 'Количество']} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {chartData.map((entry) => (
                  <Cell key={entry.name} fill={COLORS[entry.name]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </section>
      )}

      {/* Форма добавления/редактирования */}
      {showForm && canManage && (
        <section className="form-card" aria-labelledby="grade-form-title">
          <h2 id="grade-form-title" className="card-title">
            {editingGrade ? 'Редактировать оценку' : 'Новая оценка'}
          </h2>
          <form onSubmit={handleSubmit(onSubmit)} noValidate>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Ученик</label>
                <select
                  className={`form-input ${errors.studentId ? 'form-input--error' : ''}`}
                  {...register('studentId', { required: 'Выберите ученика' })}
                  disabled={!!editingGrade}
                >
                  <option value="">Выберите ученика</option>
                  {students.map((s) => (
                    <option key={s._id} value={s._id}>{s.name} ({s.class})</option>
                  ))}
                </select>
                {errors.studentId && <span className="form-error">{errors.studentId.message}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Предмет</label>
                <input
                  className={`form-input ${errors.subject ? 'form-input--error' : ''}`}
                  placeholder="Математика"
                  defaultValue={user?.subject}
                  {...register('subject', { required: 'Укажите предмет' })}
                />
                {errors.subject && <span className="form-error">{errors.subject.message}</span>}
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Оценка</label>
                <select
                  className={`form-input ${errors.value ? 'form-input--error' : ''}`}
                  {...register('value', { required: 'Выберите оценку', valueAsNumber: true })}
                >
                  <option value="">—</option>
                  {[5, 4, 3, 2, 1].map((v) => (
                    <option key={v} value={v}>{v}</option>
                  ))}
                </select>
                {errors.value && <span className="form-error">{errors.value.message}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Тип работы</label>
                <select className="form-input" {...register('type')}>
                  {Object.entries(GRADE_TYPES).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Дата</label>
                <input
                  type="date"
                  className="form-input"
                  defaultValue={new Date().toISOString().split('T')[0]}
                  {...register('date')}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Комментарий (необязательно)</label>
              <textarea
                className="form-input form-textarea"
                placeholder="Комментарий к оценке..."
                {...register('comment')}
              />
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? <><span className="btn-spinner" /> Сохранение...</> : 'Сохранить'}
              </button>
              <button type="button" className="btn btn-ghost" onClick={resetForm}>Отмена</button>
            </div>
          </form>
        </section>
      )}

      {/* Таблица оценок */}
      <section className="table-card" aria-label="Список оценок">
        {grades.length === 0 ? (
          <p className="empty-state">Оценок пока нет</p>
        ) : (
          <div className="table-wrapper">
            <table className="data-table">
              <thead>
                <tr>
                  {canManage && <th>Ученик</th>}
                  <th>Предмет</th>
                  <th>Тип</th>
                  <th>Дата</th>
                  <th>Оценка</th>
                  <th>Комментарий</th>
                  {canManage && <th>Действия</th>}
                </tr>
              </thead>
              <tbody>
                {grades.map((g) => (
                  <tr key={g._id}>
                    {canManage && <td>{g.student?.name} <span className="text-muted">({g.student?.class})</span></td>}
                    <td>{g.subject}</td>
                    <td>{GRADE_TYPES[g.type] || g.type}</td>
                    <td>{new Date(g.date).toLocaleDateString('ru-RU')}</td>
                    <td>
                      <span className={`grade-badge ${gradeColor(g.value)}`}>{g.value}</span>
                    </td>
                    <td className="text-muted">{g.comment || '—'}</td>
                    {canManage && (
                      <td>
                        <div className="action-btns">
                          <button className="btn-icon btn-icon--edit" onClick={() => handleEdit(g)} title="Редактировать">✏️</button>
                          <button className="btn-icon btn-icon--delete" onClick={() => handleDelete(g._id)} title="Удалить">🗑️</button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  )
}

export default Grades
