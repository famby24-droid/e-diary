import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { useAuth } from '../context/AuthContext'
import api from '../utils/api'
import toast from 'react-hot-toast'

const Profile = () => {
  const { user, updateUser } = useAuth()
  const [savingProfile, setSavingProfile] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const [preview, setPreview] = useState(null)

  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: { name: user?.name, class: user?.class, subject: user?.subject },
  })

  const onSaveProfile = async (data) => {
    setSavingProfile(true)
    try {
      const { data: updated } = await api.put('/auth/profile', data)
      updateUser(updated)
      toast.success('Профиль обновлён')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка сохранения')
    } finally {
      setSavingProfile(false)
    }
  }

  const handleAvatarChange = (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Файл слишком большой (максимум 5MB)')
      return
    }
    setPreview(URL.createObjectURL(file))
  }

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Файл слишком большой (максимум 5MB)')
      return
    }

    setUploadingAvatar(true)
    setPreview(URL.createObjectURL(file))

    try {
      const formData = new FormData()
      formData.append('avatar', file)
      const { data } = await api.post('/auth/avatar', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      updateUser({ avatar: data.avatar })
      toast.success('Аватар обновлён')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Ошибка загрузки')
      setPreview(null)
    } finally {
      setUploadingAvatar(false)
    }
  }

  const roleLabel = { student: 'Ученик', teacher: 'Учитель', admin: 'Администратор' }
  const avatarSrc = preview || user?.avatar

  return (
    <main className="page">
      <section className="page-header">
        <h1 className="page-title">Мой профиль</h1>
      </section>

      <div className="profile-grid">
        {/* Аватар */}
        <section className="profile-avatar-card" aria-labelledby="avatar-title">
          <h2 id="avatar-title" className="card-title">Фото профиля</h2>

          <div className="avatar-wrapper">
            {avatarSrc ? (
              <img src={avatarSrc} alt="Аватар" className="avatar-large" />
            ) : (
              <div className="avatar-large avatar-placeholder">
                {user?.name?.[0]?.toUpperCase()}
              </div>
            )}
            {uploadingAvatar && (
              <div className="avatar-loading">
                <span className="btn-spinner" />
              </div>
            )}
          </div>

          <div className="avatar-info">
            <p className="profile-name">{user?.name}</p>
            <span className={`role-badge role-badge--${user?.role}`}>
              {roleLabel[user?.role]}
            </span>
            {user?.class && <p className="profile-detail">Класс: {user.class}</p>}
            {user?.subject && <p className="profile-detail">Предмет: {user.subject}</p>}
          </div>

          <label className="btn btn-secondary btn-full upload-label" aria-busy={uploadingAvatar}>
            {uploadingAvatar ? 'Загрузка...' : '📷 Изменить фото'}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              onChange={handleAvatarUpload}
              disabled={uploadingAvatar}
            />
          </label>
          <p className="upload-hint">JPG, PNG или WEBP. Максимум 5MB.</p>
        </section>

        {/* Форма редактирования */}
        <section className="profile-form-card" aria-labelledby="profile-form-title">
          <h2 id="profile-form-title" className="card-title">Личные данные</h2>

          <form onSubmit={handleSubmit(onSaveProfile)} noValidate>
            <div className="form-group">
              <label htmlFor="name" className="form-label">Полное имя</label>
              <input
                id="name"
                type="text"
                className={`form-input ${errors.name ? 'form-input--error' : ''}`}
                {...register('name', {
                  required: 'Введите имя',
                  minLength: { value: 2, message: 'Минимум 2 символа' },
                })}
              />
              {errors.name && <span className="form-error">{errors.name.message}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-input form-input--disabled" value={user?.email} disabled />
              <p className="form-hint">Email изменить нельзя</p>
            </div>

            <div className="form-group">
              <label className="form-label">Роль</label>
              <input className="form-input form-input--disabled" value={roleLabel[user?.role]} disabled />
            </div>

            {user?.role === 'student' && (
              <div className="form-group">
                <label htmlFor="class" className="form-label">Класс</label>
                <input
                  id="class"
                  type="text"
                  className="form-input"
                  placeholder="10А"
                  {...register('class')}
                />
              </div>
            )}

            {user?.role === 'teacher' && (
              <div className="form-group">
                <label htmlFor="subject" className="form-label">Предмет</label>
                <input
                  id="subject"
                  type="text"
                  className="form-input"
                  placeholder="Математика"
                  {...register('subject')}
                />
              </div>
            )}

            <button type="submit" className="btn btn-primary" disabled={savingProfile}>
              {savingProfile ? <><span className="btn-spinner" /> Сохранение...</> : 'Сохранить изменения'}
            </button>
          </form>
        </section>
      </div>
    </main>
  )
}

export default Profile
