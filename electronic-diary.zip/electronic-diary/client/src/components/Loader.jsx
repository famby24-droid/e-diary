const Loader = ({ text = 'Загрузка...' }) => (
  <div className="loader-wrapper" role="status" aria-live="polite">
    <div className="spinner" />
    <p className="loader-text">{text}</p>
  </div>
)

export default Loader
