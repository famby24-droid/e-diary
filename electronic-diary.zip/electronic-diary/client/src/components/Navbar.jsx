import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'

const Navbar = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    toast.success('Вы вышли из системы')
    navigate('/login')
  }

  const roleLabel = {
    student: 'Ученик',
    teacher: 'Учитель',
    admin: 'Администратор',
  }

  return (
    <header className="navbar">
      <div className="navbar-brand">
        <span className="navbar-logo">📓</span>
        <span className="navbar-title">Электронный Дневник</span>
      </div>

      <nav className="navbar-links" aria-label="Главная навигация">
        <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
          Главная
        </NavLink>
        <NavLink to="/grades" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
          Оценки
        </NavLink>
        <NavLink to="/schedule" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
          Расписание
        </NavLink>
        <NavLink to="/homework" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
          Домашнее задание
        </NavLink>
        {user?.role === 'admin' && (
          <NavLink to="/admin" className={({ isActive }) => isActive ? 'nav-link active nav-link--admin' : 'nav-link nav-link--admin'}>
            Панель админа
          </NavLink>
        )}
      </nav>

      <div className="navbar-user">
        <NavLink to="/profile" className="navbar-avatar-link">
          {user?.avatar ? (
            <img src={user.avatar} alt="Аватар" className="navbar-avatar" />
          ) : (
            <div className="navbar-avatar-placeholder">
              {user?.name?.[0]?.toUpperCase()}
            </div>
          )}
          <span className="navbar-name">{user?.name}</span>
          <span className="navbar-role-badge">{roleLabel[user?.role]}</span>
        </NavLink>
        <button onClick={handleLogout} className="btn btn-ghost btn-sm">
          Выйти
        </button>
      </div>
    </header>
  )
}

export default Navbar
