import express from 'express'
import jwt from 'jsonwebtoken'
import User from '../models/User.js'
import { protect } from '../middleware/auth.js'
import { uploadAvatar } from '../middleware/upload.js'
import fs from 'fs'

const router = express.Router()

// Генерация JWT токена
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' })
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, class: userClass, subject } = req.body

    // Проверка обязательных полей
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Заполните все обязательные поля' })
    }

    // Проверка существующего пользователя
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' })
    }

    // Создание пользователя
    const user = await User.create({
      name,
      email,
      password,
      role: role || 'student',
      class: userClass,
      subject,
    })

    const token = generateToken(user._id)

    res.status(201).json({
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        class: user.class,
        subject: user.subject,
        avatar: user.avatar,
      },
    })
  } catch (error) {
    // Ошибка валидации Mongoose
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка сервера при регистрации' })
  }
})

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({ message: 'Введите email и пароль' })
    }

    const user = await User.findOne({ email })
    if (!user) {
      return res.status(401).json({ message: 'Неверный email или пароль' })
    }

    const isMatch = await user.comparePassword(password)
    if (!isMatch) {
      return res.status(401).json({ message: 'Неверный email или пароль' })
    }

    const token = generateToken(user._id)

    res.json({
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        class: user.class,
        subject: user.subject,
        avatar: user.avatar,
      },
    })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка сервера при входе' })
  }
})

// GET /api/auth/me — получить текущего пользователя
router.get('/me', protect, async (req, res) => {
  res.json(req.user)
})

// PUT /api/auth/profile — обновить профиль
router.put('/profile', protect, async (req, res) => {
  try {
    const { name, class: userClass, subject } = req.body

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { name, class: userClass, subject },
      { new: true, runValidators: true }
    ).select('-password')

    res.json(user)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка обновления профиля' })
  }
})

// POST /api/auth/avatar — загрузка аватара
router.post('/avatar', protect, uploadAvatar.single('avatar'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Файл не загружен' })
    }

    // Удаляем старый аватар если есть
    if (req.user.avatar) {
      const oldPath = req.user.avatar.replace('/uploads/', 'uploads/')
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath)
    }

    const avatarUrl = `/uploads/avatars/${req.file.filename}`
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { avatar: avatarUrl },
      { new: true }
    ).select('-password')

    res.json({ avatar: user.avatar })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка загрузки аватара' })
  }
})

export default router
