import express from 'express'
import Schedule from '../models/Schedule.js'
import { protect, requireRole } from '../middleware/auth.js'

const router = express.Router()

// GET /api/schedule — получить расписание
router.get('/', protect, async (req, res) => {
  try {
    let filter = {}

    // Ученик видит расписание своего класса
    if (req.user.role === 'student' && req.user.class) {
      filter.class = req.user.class
    } else if (req.query.class) {
      filter.class = req.query.class
    }

    if (req.query.dayOfWeek) filter.dayOfWeek = Number(req.query.dayOfWeek)

    const schedule = await Schedule.find(filter)
      .populate('teacher', 'name subject')
      .sort({ dayOfWeek: 1, lessonNumber: 1 })

    res.json(schedule)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка получения расписания' })
  }
})

// POST /api/schedule — создать урок (только админ)
router.post('/', protect, requireRole('admin'), async (req, res) => {
  try {
    const { class: cls, dayOfWeek, lessonNumber, subject, teacher, room, startTime, endTime } = req.body

    if (!cls || !dayOfWeek || !lessonNumber || !subject) {
      return res.status(400).json({ message: 'Заполните обязательные поля' })
    }

    const lesson = await Schedule.create({ class: cls, dayOfWeek, lessonNumber, subject, teacher, room, startTime, endTime })
    const populated = await lesson.populate('teacher', 'name subject')
    res.status(201).json(populated)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка создания урока' })
  }
})

// PUT /api/schedule/:id
router.put('/:id', protect, requireRole('admin'), async (req, res) => {
  try {
    const lesson = await Schedule.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate('teacher', 'name subject')

    if (!lesson) return res.status(404).json({ message: 'Урок не найден' })
    res.json(lesson)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка обновления урока' })
  }
})

// DELETE /api/schedule/:id
router.delete('/:id', protect, requireRole('admin'), async (req, res) => {
  try {
    const lesson = await Schedule.findByIdAndDelete(req.params.id)
    if (!lesson) return res.status(404).json({ message: 'Урок не найден' })
    res.json({ message: 'Урок удалён' })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка удаления урока' })
  }
})

export default router
