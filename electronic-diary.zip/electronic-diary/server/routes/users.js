import express from 'express'
import User from '../models/User.js'
import { protect, requireRole } from '../middleware/auth.js'

const router = express.Router()

// GET /api/users — все пользователи (только для admin)
router.get('/', protect, requireRole('admin', 'teacher'), async (req, res) => {
  try {
    let filter = {}
    if (req.query.role) filter.role = req.query.role
    if (req.query.class) filter.class = req.query.class

    // Учитель может видеть только учеников
    if (req.user.role === 'teacher') filter.role = 'student'

    const users = await User.find(filter).select('-password').sort({ name: 1 })
    res.json(users)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка получения пользователей' })
  }
})

// PUT /api/users/:id — изменить пользователя (только admin)
router.put('/:id', protect, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, role, class: userClass, subject } = req.body

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, role, class: userClass, subject },
      { new: true, runValidators: true }
    ).select('-password')

    if (!user) return res.status(404).json({ message: 'Пользователь не найден' })
    res.json(user)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка обновления пользователя' })
  }
})

// DELETE /api/users/:id — удалить пользователя (только admin)
router.delete('/:id', protect, requireRole('admin'), async (req, res) => {
  try {
    // Нельзя удалить самого себя
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ message: 'Нельзя удалить собственный аккаунт' })
    }

    const user = await User.findByIdAndDelete(req.params.id)
    if (!user) return res.status(404).json({ message: 'Пользователь не найден' })

    res.json({ message: `Пользователь ${user.name} удалён` })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка удаления пользователя' })
  }
})

export default router
