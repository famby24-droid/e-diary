import express from 'express'
import Homework from '../models/Homework.js'
import { protect, requireRole } from '../middleware/auth.js'
import { uploadHomework } from '../middleware/upload.js'

const router = express.Router()

// GET /api/homework
router.get('/', protect, async (req, res) => {
  try {
    let filter = {}

    if (req.user.role === 'student' && req.user.class) {
      filter.class = req.user.class
    } else if (req.query.class) {
      filter.class = req.query.class
    }

    if (req.user.role === 'teacher') {
      filter.teacher = req.user._id
    }

    if (req.query.subject) filter.subject = req.query.subject

    const homework = await Homework.find(filter)
      .populate('teacher', 'name subject')
      .sort({ dueDate: 1 })

    res.json(homework)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка получения заданий' })
  }
})

// POST /api/homework — с возможностью загрузки файлов
router.post('/', protect, requireRole('teacher', 'admin'), uploadHomework.array('attachments', 5), async (req, res) => {
  try {
    const { class: cls, subject, description, dueDate } = req.body

    if (!cls || !subject || !description || !dueDate) {
      return res.status(400).json({ message: 'Заполните все обязательные поля' })
    }

    const attachments = req.files?.map((f) => ({
      filename: f.filename,
      originalName: f.originalname,
      path: `/uploads/homework/${f.filename}`,
    })) || []

    const hw = await Homework.create({
      class: cls,
      subject,
      teacher: req.user._id,
      description,
      dueDate,
      attachments,
    })

    const populated = await hw.populate('teacher', 'name subject')
    res.status(201).json(populated)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка создания задания' })
  }
})

// PUT /api/homework/:id
router.put('/:id', protect, requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const hw = await Homework.findById(req.params.id)
    if (!hw) return res.status(404).json({ message: 'Задание не найдено' })

    if (req.user.role === 'teacher' && hw.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на редактирование этого задания' })
    }

    const { description, dueDate } = req.body
    const updated = await Homework.findByIdAndUpdate(
      req.params.id,
      { description, dueDate },
      { new: true, runValidators: true }
    ).populate('teacher', 'name subject')

    res.json(updated)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка обновления задания' })
  }
})

// DELETE /api/homework/:id
router.delete('/:id', protect, requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const hw = await Homework.findById(req.params.id)
    if (!hw) return res.status(404).json({ message: 'Задание не найдено' })

    if (req.user.role === 'teacher' && hw.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на удаление этого задания' })
    }

    await hw.deleteOne()
    res.json({ message: 'Задание удалено' })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка удаления задания' })
  }
})

export default router
