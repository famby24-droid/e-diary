import express from 'express'
import Grade from '../models/Grade.js'
import { protect, requireRole } from '../middleware/auth.js'

const router = express.Router()

// GET /api/grades — получить оценки
// Ученик видит только свои, учитель — своих учеников, админ — все
router.get('/', protect, async (req, res) => {
  try {
    let filter = {}

    if (req.user.role === 'student') {
      filter.student = req.user._id
    } else if (req.user.role === 'teacher') {
      filter.teacher = req.user._id
    }

    // Опциональная фильтрация по предмету
    if (req.query.subject) filter.subject = req.query.subject
    if (req.query.studentId && req.user.role !== 'student') {
      filter.student = req.query.studentId
    }

    const grades = await Grade.find(filter)
      .populate('student', 'name class')
      .populate('teacher', 'name subject')
      .sort({ date: -1 })

    res.json(grades)
  } catch (error) {
    res.status(500).json({ message: 'Ошибка получения оценок' })
  }
})

// POST /api/grades — добавить оценку (только учитель или админ)
router.post('/', protect, requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const { studentId, subject, value, comment, date, type } = req.body

    if (!studentId || !subject || !value) {
      return res.status(400).json({ message: 'Укажите ученика, предмет и оценку' })
    }

    const grade = await Grade.create({
      student: studentId,
      teacher: req.user._id,
      subject,
      value,
      comment,
      date: date || Date.now(),
      type,
    })

    const populated = await grade.populate([
      { path: 'student', select: 'name class' },
      { path: 'teacher', select: 'name subject' },
    ])

    res.status(201).json(populated)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка добавления оценки' })
  }
})

// PUT /api/grades/:id — изменить оценку
router.put('/:id', protect, requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const grade = await Grade.findById(req.params.id)
    if (!grade) return res.status(404).json({ message: 'Оценка не найдена' })

    // Учитель может редактировать только свои оценки
    if (req.user.role === 'teacher' && grade.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на редактирование этой оценки' })
    }

    const { value, comment, date, type } = req.body
    const updated = await Grade.findByIdAndUpdate(
      req.params.id,
      { value, comment, date, type },
      { new: true, runValidators: true }
    ).populate([
      { path: 'student', select: 'name class' },
      { path: 'teacher', select: 'name subject' },
    ])

    res.json(updated)
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message)
      return res.status(400).json({ message: messages.join('. ') })
    }
    res.status(500).json({ message: 'Ошибка обновления оценки' })
  }
})

// DELETE /api/grades/:id — удалить оценку
router.delete('/:id', protect, requireRole('teacher', 'admin'), async (req, res) => {
  try {
    const grade = await Grade.findById(req.params.id)
    if (!grade) return res.status(404).json({ message: 'Оценка не найдена' })

    if (req.user.role === 'teacher' && grade.teacher.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на удаление этой оценки' })
    }

    await grade.deleteOne()
    res.json({ message: 'Оценка удалена' })
  } catch (error) {
    res.status(500).json({ message: 'Ошибка удаления оценки' })
  }
})

export default router
