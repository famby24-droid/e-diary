import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'
import connectDB from './config/db.js'

import authRoutes from './routes/auth.js'
import gradesRoutes from './routes/grades.js'
import scheduleRoutes from './routes/schedule.js'
import homeworkRoutes from './routes/homework.js'
import usersRoutes from './routes/users.js'

dotenv.config()

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Подключение к MongoDB
connectDB()

const app = express()

// Безопасность
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }))

// CORS
app.use(
  cors({
    origin: process.env.CLIENT_URL || 'http://localhost:5173',
    credentials: true,
  })
)

// Парсинг JSON
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Статические файлы (загруженные медиа)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

// Маршруты API
app.use('/api/auth', authRoutes)
app.use('/api/grades', gradesRoutes)
app.use('/api/schedule', scheduleRoutes)
app.use('/api/homework', homeworkRoutes)
app.use('/api/users', usersRoutes)

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() })
})

// Обработка несуществующих API маршрутов (404)
app.use('/api/*', (req, res) => {
  res.status(404).json({ message: `Маршрут ${req.originalUrl} не найден` })
})

// Глобальный обработчик ошибок
app.use((err, req, res, next) => {
  console.error('Ошибка сервера:', err.stack)

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ message: 'Файл слишком большой' })
  }

  res.status(err.status || 500).json({
    message: err.message || 'Внутренняя ошибка сервера',
  })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`🚀 Сервер запущен на порту ${PORT}`)
  console.log(`📡 API доступен: http://localhost:${PORT}/api`)
})
