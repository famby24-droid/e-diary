import jwt from 'jsonwebtoken'
import User from '../models/User.js'

// Проверка JWT токена
export const protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Нет токена авторизации' })
    }

    const token = authHeader.split(' ')[1]
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    const user = await User.findById(decoded.id).select('-password')
    if (!user) {
      return res.status(401).json({ message: 'Пользователь не найден' })
    }

    req.user = user
    next()
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Токен истёк, войдите снова' })
    }
    return res.status(401).json({ message: 'Токен недействителен' })
  }
}

// Проверка роли пользователя
export const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        message: `Доступ запрещён. Требуется роль: ${roles.join(' или ')}`,
      })
    }
    next()
  }
}
