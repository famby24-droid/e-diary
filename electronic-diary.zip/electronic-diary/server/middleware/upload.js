import multer from 'multer'
import path from 'path'
import fs from 'fs'

// Создаём папки если нет
const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
}

// Хранилище для аватаров
const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = 'uploads/avatars'
    ensureDir(dir)
    cb(null, dir)
  },
  filename: (req, file, cb) => {
    const uniqueName = `avatar-${req.user._id}-${Date.now()}${path.extname(file.originalname)}`
    cb(null, uniqueName)
  },
})

// Хранилище для вложений к ДЗ
const homeworkStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = 'uploads/homework'
    ensureDir(dir)
    cb(null, dir)
  },
  filename: (req, file, cb) => {
    const uniqueName = `hw-${Date.now()}-${file.originalname}`
    cb(null, uniqueName)
  },
})

// Фильтр: только изображения для аватара
const imageFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
  if (allowed.includes(file.mimetype)) {
    cb(null, true)
  } else {
    cb(new Error('Разрешены только изображения (jpg, png, webp)'), false)
  }
}

export const uploadAvatar = multer({
  storage: avatarStorage,
  fileFilter: imageFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
})

export const uploadHomework = multer({
  storage: homeworkStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
})
