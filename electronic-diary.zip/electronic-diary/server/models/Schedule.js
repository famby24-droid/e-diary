import mongoose from 'mongoose'

const scheduleSchema = new mongoose.Schema(
  {
    class: {
      type: String,
      required: [true, 'Класс обязателен'],
      trim: true,
    },
    dayOfWeek: {
      type: Number,
      required: [true, 'День недели обязателен'],
      min: 1, // Понедельник
      max: 6, // Суббота
    },
    lessonNumber: {
      type: Number,
      required: [true, 'Номер урока обязателен'],
      min: 1,
      max: 8,
    },
    subject: {
      type: String,
      required: [true, 'Предмет обязателен'],
      trim: true,
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    room: {
      type: String,
      trim: true,
    },
    startTime: {
      type: String, // "08:00"
    },
    endTime: {
      type: String, // "08:45"
    },
  },
  { timestamps: true }
)

export default mongoose.model('Schedule', scheduleSchema)
