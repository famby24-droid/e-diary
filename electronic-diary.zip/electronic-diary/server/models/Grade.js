import mongoose from 'mongoose'

const gradeSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Ученик обязателен'],
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Учитель обязателен'],
    },
    subject: {
      type: String,
      required: [true, 'Предмет обязателен'],
      trim: true,
    },
    value: {
      type: Number,
      required: [true, 'Оценка обязательна'],
      min: [1, 'Минимальная оценка: 1'],
      max: [5, 'Максимальная оценка: 5'],
    },
    comment: {
      type: String,
      trim: true,
      maxlength: [500, 'Комментарий не более 500 символов'],
    },
    date: {
      type: Date,
      default: Date.now,
    },
    type: {
      type: String,
      enum: ['classwork', 'homework', 'test', 'exam'],
      default: 'classwork',
    },
  },
  { timestamps: true }
)

export default mongoose.model('Grade', gradeSchema)
