import mongoose from 'mongoose'

const homeworkSchema = new mongoose.Schema(
  {
    class: {
      type: String,
      required: [true, 'Класс обязателен'],
      trim: true,
    },
    subject: {
      type: String,
      required: [true, 'Предмет обязателен'],
      trim: true,
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    description: {
      type: String,
      required: [true, 'Описание задания обязательно'],
      trim: true,
      maxlength: [2000, 'Описание не более 2000 символов'],
    },
    dueDate: {
      type: Date,
      required: [true, 'Срок сдачи обязателен'],
    },
    attachments: [
      {
        filename: String,
        originalName: String,
        path: String,
      },
    ],
  },
  { timestamps: true }
)

export default mongoose.model('Homework', homeworkSchema)
