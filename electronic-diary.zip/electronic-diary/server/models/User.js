import mongoose from 'mongoose'
import bcrypt from 'bcryptjs'

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Имя обязательно'],
      trim: true,
      minlength: [2, 'Имя должно содержать минимум 2 символа'],
      maxlength: [50, 'Имя не должно превышать 50 символов'],
    },
    email: {
      type: String,
      required: [true, 'Email обязателен'],
      unique: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Введите корректный email'],
    },
    password: {
      type: String,
      required: [true, 'Пароль обязателен'],
      minlength: [6, 'Пароль должен содержать минимум 6 символов'],
    },
    role: {
      type: String,
      enum: ['student', 'teacher', 'admin'],
      default: 'student',
    },
    // Для учеников: класс (например "10А")
    class: {
      type: String,
      trim: true,
    },
    // Для учителей: предмет
    subject: {
      type: String,
      trim: true,
    },
    avatar: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
)

// Хешируем пароль перед сохранением
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next()
  this.password = await bcrypt.hash(this.password, 12)
  next()
})

// Метод сравнения паролей
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password)
}

export default mongoose.model('User', userSchema)
